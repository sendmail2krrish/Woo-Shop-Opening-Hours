<div id="KWooPopup" class="KWooOverlay">
	<div class="KWooPopup">
		<h2><?php echo KWoo_Get_Shop_Opening_Hours('kwoo_soh_popup_heading'); ?></h2>
		<div class="KWooContent">
			<?php echo KWoo_Get_Shop_Opening_Hours('kwoo_soh_popup_msg'); ?>
		</div>
		<a class="KWooClose" href="javascript:close_KWoo_popup()">OK</a>
	</div>
</div>