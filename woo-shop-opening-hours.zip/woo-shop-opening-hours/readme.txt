=== Woo Shop Opening Hours ===
Contributors: sendmail2krrish 
Donate link: https://www.paypal.me/paytokrishna
Tags: woocommerce, WooCommerce, wooCommerce, shopping, shop, ecommence, eCommerce, open, close, opening hours, shop opening hours, wordpress ecommerce
Requires at least: 3.5.0
Tested up to: 4.9.4
Stable tag: 4.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Woo Shop Opening Hours

== Description ==

Woo Shop Opening Hours

Woocommerce shop availability plugin. Admin can set a message when their shop is close for all the user who will use this website. User will get this message when they will visit checkout page. No need to use any shortcode. Just active it and use it.

<h4>The features of the Woo Shop Opening Hours plugin:</h4>

<ul>
<li>Set shop open time & close time</li>
<li>Set close shop if shop is not available in any day of week</li>
<li>Set message for all users</li>
</ul>

== Installation ==

Upload the Woo Shop Opening Hours FAQ plugin, Activate it.

e.g.

1. Upload `wooshopavailability` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress.

== Frequently Asked Questions ==

= Where is located? =

Check your left sidebar & you will see there is a menu called `OpeningHours`. Click on that & use it.


== Screenshots ==

1. Settings page.
3. Popup.

== Changelog ==

= 1.0 =
* Latest version

== Upgrade Notice ==

Pro version Comming soon. 